"""Re-trocear el corpus con cortes en párrafos y reconstruir el índice.

Mejoras sobre el troceado base (ventana fija de ~500 tokens, 80 de solape):

1. **Corte en párrafos.** Nunca se parte a mitad de párrafo; si un párrafo
   entero cabe, entra completo. Solo se corta dentro de un párrafo si ese
   párrafo solo ya supera `max_tokens`.
2. **Cabecera de contexto.** Cada fragmento arranca con
   «NVIDIA · FY2025 · Item 1A — Risk Factors», para que BM25 y el denso
   tengan el contexto del documento aunque el chunk quede lejos del inicio.
3. **Solape por párrafo.** El solape arrastra el último párrafo del chunk
   anterior (no una ventana de caracteres fija), así no se corta una frase
   a medias.
4. **Tokens reales.** Se usa `tiktoken` (codificador cl100k_base, el que usan
   la mayoría de modelos) en vez de `len(texto) // 4`.

Uso:
    uv run python scripts/rechunkear.py                       # por defecto 480 tokens, escribe corpus/
    uv run python scripts/rechunkear.py --max-tokens 600      # chunks más grandes
    uv run python scripts/rechunkear.py --solo-chunks         # no reconstruye FAISS (no necesita GPU)
    uv run python scripts/rechunkear.py --dry-run             # solo imprime estadísticas

El script regenera:
    corpus/chunks.jsonl
    corpus/indice/chunks_meta.parquet
    corpus/indice/corpus.faiss
    corpus/indice/MANIFEST.md
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import time
from pathlib import Path

import numpy as np
import pandas as pd

# ── parámetros por defecto ────────────────────────────────────────────────
MAX_TOKENS = 520
MIN_TOKENS = 60        # no crear chunks más cortos que esto

ITEMS = {
    "1A": "Risk Factors",
    "7":  "Management's Discussion and Analysis",
    "7A": "Quantitative and Qualitative Disclosures About Market Risk",
    "8":  "Financial Statements and Supplementary Data",
}

TICKERS_NOMBRE = {
    "NVDA": "NVIDIA", "MSFT": "Microsoft", "AAPL": "Apple",
    "GOOGL": "Alphabet", "META": "Meta", "AMZN": "Amazon",
}

MODELO_EMBEDDINGS = "BAAI/bge-small-en-v1.5"
PREFIJO_BGE = "Represent this sentence for searching relevant passages: "

# ── tokenización ──────────────────────────────────────────────────────────
_ENC = None

def contar_tokens(texto: str) -> int:
    global _ENC
    if _ENC is None:
        try:
            import tiktoken
            _ENC = tiktoken.get_encoding("cl100k_base")
        except Exception:
            # Fallback: ~1 token por 3.5 chars (conservative, better than //4)
            _ENC = "fallback"
    if _ENC == "fallback":
        return max(1, int(len(texto) / 3.5))
    return len(_ENC.encode(texto))


# ── detección de tablas ───────────────────────────────────────────────────
_RE_TABLA = re.compile(
    r"""
    (?: ^\|.+\|$            # fila markdown con pipes
    |   \t.*\t              # TSV
    |   \$\s*[\d,.]+\s*\$   # $123,456$
    |   ^\s{4,}\S+\s{3,}\S  # columnas alineadas con espacios
    )""",
    re.VERBOSE | re.MULTILINE,
)

def contiene_tabla(texto: str) -> bool:
    return bool(_RE_TABLA.search(texto))


# ── el troceador ──────────────────────────────────────────────────────────

def _cabecera(ticker: str, fiscal_year: int, item: str) -> str:
    nombre = TICKERS_NOMBRE.get(ticker, ticker)
    seccion = ITEMS.get(item, f"Item {item}")
    return f"{nombre} ({ticker}) · FY{fiscal_year} · Item {item} — {seccion}\n\n"


def _dividir_parrafos(texto: str) -> list[str]:
    """Divide por doble salto de línea; conserva saltos simples dentro."""
    bloques = re.split(r"\n{2,}", texto)
    return [b.strip() for b in bloques if b.strip()]


def trocear_seccion(
    texto: str,
    ticker: str,
    fiscal_year: int,
    item: str,
    max_tokens: int = MAX_TOKENS,
) -> list[dict]:
    """Devuelve una lista de chunks con sus metadatos."""

    cabecera = _cabecera(ticker, fiscal_year, item)
    tokens_cabecera = contar_tokens(cabecera)
    budget = max_tokens - tokens_cabecera

    parrafos = _dividir_parrafos(texto)
    if not parrafos:
        return []

    chunks: list[dict] = []
    buffer: list[str] = []
    buffer_tokens = 0
    pos_inicio = 0   # posición en caracteres del inicio del chunk actual

    def _flush(paragraphs: list[str], inicio: int) -> None:
        if not paragraphs:
            return
        cuerpo = "\n\n".join(paragraphs)
        texto_final = cabecera + cuerpo
        tok = contar_tokens(texto_final)
        if tok < MIN_TOKENS and chunks:
            # Demasiado corto: pegar al chunk anterior
            prev = chunks[-1]
            prev["texto"] = prev["texto"] + "\n\n" + cuerpo
            prev["n_tokens"] = contar_tokens(prev["texto"])
            prev["fin_car"] = inicio + len(cuerpo)
            prev["contiene_tabla"] = prev["contiene_tabla"] or contiene_tabla(cuerpo)
            return

        idx = len(chunks)
        chunk_id = f"{ticker}-{fiscal_year}-{item}-{idx:04d}"
        chunks.append({
            "chunk_id": chunk_id,
            "ticker": ticker,
            "fiscal_year": fiscal_year,
            "item": item,
            "posicion": idx,
            "texto": texto_final,
            "n_tokens": tok,
            "contiene_tabla": contiene_tabla(cuerpo),
            "inicio_car": inicio,
            "fin_car": inicio + len(cuerpo),
        })

    char_pos = 0
    for p in parrafos:
        p_tokens = contar_tokens(p)

        if p_tokens > budget:
            # Paragraph too big: flush current buffer, then split paragraph
            _flush(buffer, pos_inicio)
            buffer = []
            buffer_tokens = 0

            # Split long paragraph by sentences
            sentences = re.split(r'(?<=[.!?])\s+', p)
            sent_buf: list[str] = []
            sent_tokens = 0
            sent_start = char_pos
            for s in sentences:
                s_tok = contar_tokens(s)
                if sent_tokens + s_tok > budget and sent_buf:
                    _flush(sent_buf, sent_start)
                    sent_buf = []
                    sent_tokens = 0
                    sent_start = char_pos
                sent_buf.append(s)
                sent_tokens += s_tok
            if sent_buf:
                _flush(sent_buf, sent_start)
            pos_inicio = char_pos + len(p)

        elif buffer_tokens + p_tokens > budget:
            # Flush and start new chunk
            _flush(buffer, pos_inicio)
            buffer = [p]
            buffer_tokens = p_tokens
            pos_inicio = char_pos
        else:
            if not buffer:
                pos_inicio = char_pos
            buffer.append(p)
            buffer_tokens += p_tokens

        char_pos += len(p) + 2  # +2 for the \n\n separator

    # Flush remaining
    _flush(buffer, pos_inicio)
    return chunks


# ── reconstruir el índice FAISS ───────────────────────────────────────────

def construir_indice(chunks: list[dict], destino: Path) -> None:
    import faiss
    from sentence_transformers import SentenceTransformer

    print(f"  Cargando {MODELO_EMBEDDINGS}…")
    codificador = SentenceTransformer(MODELO_EMBEDDINGS)

    textos = [c["texto"] for c in chunks]
    print(f"  Codificando {len(textos)} fragmentos…")
    t0 = time.perf_counter()
    # The BGE model prefixes queries, not documents — documents go as-is
    embeddings = codificador.encode(
        textos,
        normalize_embeddings=True,
        convert_to_numpy=True,
        show_progress_bar=True,
        batch_size=64,
    ).astype("float32")
    print(f"  → {time.perf_counter() - t0:.1f}s")

    dim = embeddings.shape[1]
    indice = faiss.IndexFlatIP(dim)  # inner product on normalized = cosine
    indice.add(embeddings)

    destino.mkdir(parents=True, exist_ok=True)
    faiss.write_index(indice, str(destino / "corpus.faiss"))

    meta = pd.DataFrame([{
        "chunk_id": c["chunk_id"],
        "ticker": c["ticker"],
        "fiscal_year": c["fiscal_year"],
        "item": c["item"],
        "texto": c["texto"],
        "n_tokens": c["n_tokens"],
        "contiene_tabla": c["contiene_tabla"],
    } for c in chunks])
    meta.to_parquet(destino / "chunks_meta.parquet", index=False)

    # Write manifest
    sha = hashlib.sha256(
        json.dumps([c["chunk_id"] for c in chunks]).encode()
    ).hexdigest()[:16]
    (destino / "MANIFEST.md").write_text(
        f"# Índice reconstruido\n\n"
        f"- Fragmentos: {len(chunks)}\n"
        f"- Modelo: {MODELO_EMBEDDINGS}\n"
        f"- Prefijo consulta: `{PREFIJO_BGE}`\n"
        f"- Hash chunk_ids: {sha}\n",
        encoding="utf-8",
    )
    print(f"  → {destino}/corpus.faiss ({indice.ntotal} vectores, dim={dim})")


# ── main ──────────────────────────────────────────────────────────────────

def main() -> int:
    parser = argparse.ArgumentParser(description="Re-trocear el corpus 10-K.")
    parser.add_argument("--max-tokens", type=int, default=MAX_TOKENS)
    parser.add_argument("--solo-chunks", action="store_true",
                        help="No reconstruir FAISS (no necesita el modelo de embeddings).")
    parser.add_argument("--dry-run", action="store_true",
                        help="Solo imprime estadísticas; no escribe nada.")
    args = parser.parse_args()

    from agente.corpus import dir_corpus, raiz_repo

    corpus = dir_corpus()
    secciones = [json.loads(l) for l in (corpus / "secciones.jsonl").open(encoding="utf-8")
                 if l.strip()]

    print(f"{len(secciones)} secciones · max_tokens={args.max_tokens}")

    todos: list[dict] = []
    for sec in secciones:
        nuevos = trocear_seccion(
            sec["texto"], sec["ticker"], sec["fiscal_year"], sec["item"],
            max_tokens=args.max_tokens,
        )
        todos.extend(nuevos)

    tokens = [c["n_tokens"] for c in todos]
    print(f"\nResultado: {len(todos)} fragmentos")
    print(f"  tokens: min={min(tokens)}, max={max(tokens)}, "
          f"mean={sum(tokens)/len(tokens):.0f}, median={sorted(tokens)[len(tokens)//2]}")

    # Compare with original
    original = [json.loads(l) for l in (corpus / "chunks.jsonl").open(encoding="utf-8")
                if l.strip()]
    print(f"  original: {len(original)} fragmentos, "
          f"mean={sum(c['n_tokens'] for c in original)/len(original):.0f} tokens")

    # Check anchor coverage for the golden set
    golden_path = raiz_repo() / "data" / "golden_set.jsonl"
    if golden_path.is_file():
        golden = [json.loads(l) for l in golden_path.read_text(encoding="utf-8").splitlines()
                  if l.strip()]
        found = 0
        total = 0
        for g in golden:
            ancla = g.get("ancla_texto")
            if not ancla:
                continue
            total += 1
            ancla_lower = ancla.lower()
            for c in todos:
                if (c["ticker"] == g.get("ticker")
                        and int(c["fiscal_year"]) == int(g.get("fiscal_year", -1))
                        and ancla_lower in c["texto"].lower()):
                    found += 1
                    break
        print(f"\n  Cobertura de anclas: {found}/{total} "
              f"({found/total:.0%})")

    if args.dry_run:
        print("\n  (dry-run: no se escribe nada)")
        return 0

    # Write chunks.jsonl
    ruta_chunks = corpus / "chunks.jsonl"
    with ruta_chunks.open("w", encoding="utf-8") as fh:
        for c in todos:
            fh.write(json.dumps(c, ensure_ascii=False) + "\n")
    print(f"\n  → {ruta_chunks}")

    if not args.solo_chunks:
        construir_indice(todos, corpus / "indice")
    else:
        # At minimum update chunks_meta
        meta = pd.DataFrame([{
            "chunk_id": c["chunk_id"],
            "ticker": c["ticker"],
            "fiscal_year": c["fiscal_year"],
            "item": c["item"],
            "texto": c["texto"],
            "n_tokens": c["n_tokens"],
            "contiene_tabla": c["contiene_tabla"],
        } for c in todos])
        meta.to_parquet(corpus / "indice" / "chunks_meta.parquet", index=False)
        print(f"  → {corpus}/indice/chunks_meta.parquet")
        print("  ⚠ FAISS no reconstruido: ejecuta sin --solo-chunks "
              "para que el denso funcione con el nuevo troceado.")

    # Invalidate corpus caches
    from agente.corpus import cargar_chunks
    cargar_chunks.cache_clear()

    print("\n✓ Hecho. Ahora ejecuta las evaluaciones para medir el delta:")
    print("    uv run python -m agente.cli recall")
    print("    uv run python -m agente.cli todo --arq a4_comparativas --reps 3")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
